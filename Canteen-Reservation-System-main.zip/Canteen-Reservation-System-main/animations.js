// var historyContent = document.querySelector('#history-content');
// var m3 = document.getElementsByClassName('.our-history');

// document.addEventListener('scroll', () => {
//     if (window.scrollY >= historyContent.getBoundingClientRect().top) {
//         historyContent.classList.add('opacity');
//         historyContent.classList.add('fromLeftToRight-animation');
//     }
// })




